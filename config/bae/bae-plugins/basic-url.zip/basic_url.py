from wstore.asset_manager.resource_plugins.plugin import Plugin

class BasicPlugin(Plugin):
    pass
